package com.rachai.attendance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rachai.attendance.model.AttendanceRecord;

@Repository
public interface AttendanceRecordRepository extends JpaRepository<AttendanceRecord, Long> {

    @Query("SELECT ar FROM AttendanceRecord ar WHERE ar.session.classGroup.id = :classGroupId AND ar.student.id = :studentId")
    List<AttendanceRecord> findByClassGroupIdAndStudentId(@Param("classGroupId") Long classGroupId,
                                                           @Param("studentId") Long studentId);

    @Query("SELECT COUNT(ar) FROM AttendanceRecord ar WHERE ar.session.classGroup.id = :classGroupId AND ar.student.id = :studentId AND ar.present = true")
    long countPresences(@Param("classGroupId") Long classGroupId, @Param("studentId") Long studentId);

    @Query("SELECT COUNT(ar) FROM AttendanceRecord ar WHERE ar.session.classGroup.id = :classGroupId AND ar.student.id = :studentId")
    long countTotalRecords(@Param("classGroupId") Long classGroupId, @Param("studentId") Long studentId);

    List<AttendanceRecord> findBySessionId(Long sessionId);
}
