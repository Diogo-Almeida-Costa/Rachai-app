package com.rachai.attendance.instance.rule;

import com.rachai.attendance.instance.resource.WorkloadResource;
import com.rachai.framework.core.user.User;
import com.rachai.framework.extension.rule.ISplitRule;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Regra de divisão do PontoAI: compensação da carga horária total com base
 * na assiduidade real detectada de cada participante.
 *
 * Diferente da {@code EqualSplitRule} do RachAI (que apenas divide o valor
 * igualmente), esta regra usa a taxa de presença real de cada participante
 * — calculada a partir dos registros de frequência já confirmados — para
 * determinar quantas horas daquele total ainda precisam ser compensadas.
 *
 * horasACompensar = cargaHorariaTotal * (1 - assiduidadeReal)
 */
public class AttendanceCompensationRule implements ISplitRule<WorkloadResource> {

    private final Map<Long, BigDecimal> attendanceRateByUserId;

    /**
     * @param attendanceRateByUserId taxa de assiduidade real (entre 0 e 1)
     *                                de cada participante, indexada por ID
     *                                de usuário. Participantes ausentes do
     *                                mapa são tratados como 100% assíduos.
     */
    public AttendanceCompensationRule(Map<Long, BigDecimal> attendanceRateByUserId) {
        this.attendanceRateByUserId = attendanceRateByUserId != null ? attendanceRateByUserId : new HashMap<>();
    }

    @Override
    public Map<User, BigDecimal> split(WorkloadResource resource, List<User> participants) {
        Map<User, BigDecimal> compensation = new HashMap<>();
        if (participants == null || participants.isEmpty() || resource.getAmount() == null) {
            return compensation;
        }

        for (User participant : participants) {
            BigDecimal attendanceRate = attendanceRateByUserId.getOrDefault(participant.getId(), BigDecimal.ONE);

            // Garante que a taxa fique sempre entre 0 e 1, mesmo com dados inconsistentes
            BigDecimal clampedRate = attendanceRate.max(BigDecimal.ZERO).min(BigDecimal.ONE);
            BigDecimal absenceRate = BigDecimal.ONE.subtract(clampedRate);

            BigDecimal hoursToCompensate = resource.getAmount()
                    .multiply(absenceRate)
                    .setScale(2, RoundingMode.HALF_UP);

            compensation.put(participant, hoursToCompensate);
        }

        return compensation;
    }
}
