package com.rachai.attendance.instance.ai;

import com.rachai.framework.extension.ai.IAIConfig;
import org.springframework.stereotype.Component;

/**
 * Configuração de IA do PontoAI: define como o {@code ContextManager} do
 * framework deve montar o prompt para o recurso sugerido pela IA — a
 * recomendação inteligente de atividades extras para compensar faltas.
 *
 * É o equivalente, nesta instanciação, ao {@code RachAIConfig} do RachAI.
 */
@Component
public class PontoAIConfig implements IAIConfig {

    @Override
    public String getSystemInstructions() {
        return "Você é o assistente do PontoAI, especialista em controle de frequência, assiduidade " +
               "e em recomendar atividades extras justas para compensar a carga horária perdida por faltas.";
    }

    @Override
    public String getDomainContext() {
        return "O PontoAI analisa a assiduidade real detectada de cada participante de uma turma e a " +
               "carga horária total que precisa ser cumprida, sugerindo atividades extras proporcionais " +
               "às horas em falta de cada um.";
    }

    @Override
    public String getResponseSchema() {
        return "{ \"activities\": [\"string\"], \"totalCompensationHours\": \"number\", " +
               "\"confidence\": \"number\", \"reasoning\": \"string\" }";
    }
}
