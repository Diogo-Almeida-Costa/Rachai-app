package com.rachai.attendance.dto.classGroupDTOs;

import lombok.*;
import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClassGroupRequestDTO {
    private String name;
    private String description;
    private BigDecimal totalWorkloadHours;
}
