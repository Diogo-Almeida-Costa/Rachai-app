package com.rachai.attendance.dto;

import lombok.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Resultado da extração automatizada (OCR) de uma lista de presença física
 * assinada. É o "T" produzido pela extensão {@code IOCRExtension<T>} desta
 * instanciação (PontoAI), análogo ao {@code ExpenseResource} extraído pelo
 * {@code ReceiptOCRExtension} do RachAI.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceExtractionDTO {

    /** Data do encontro identificada na lista de presença. */
    private LocalDate sessionDate;

    /** Assunto/tópico da aula, quando identificável no cabeçalho da lista. */
    private String topic;

    /** Uma entrada por participante encontrado na lista assinada. */
    private List<ExtractedEntry> entries = new ArrayList<>();

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ExtractedEntry {
        /** Nome do participante conforme lido na lista. */
        private String name;
        /** Indica se foi detectada assinatura/marcação de presença. */
        private boolean present;
    }
}
