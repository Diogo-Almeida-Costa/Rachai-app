package com.rachai.attendance.dto;

import com.rachai.framework.core.user.User;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Resultado consolidado de um processamento de frequência via framework:
 * quanto cada participante precisa compensar de carga horária (com base na
 * assiduidade real detectada) e a sugestão de atividades extras gerada
 * pela IA para cobrir essas faltas.
 */
public class AttendanceFrameworkResultDTO {

    private Map<User, BigDecimal> hoursToCompensate;
    private CompensationSuggestionDTO aiSuggestion;

    public AttendanceFrameworkResultDTO() {}

    public AttendanceFrameworkResultDTO(Map<User, BigDecimal> hoursToCompensate, CompensationSuggestionDTO aiSuggestion) {
        this.hoursToCompensate = hoursToCompensate;
        this.aiSuggestion = aiSuggestion;
    }

    public Map<User, BigDecimal> getHoursToCompensate() { return hoursToCompensate; }
    public void setHoursToCompensate(Map<User, BigDecimal> hoursToCompensate) { this.hoursToCompensate = hoursToCompensate; }

    public CompensationSuggestionDTO getAiSuggestion() { return aiSuggestion; }
    public void setAiSuggestion(CompensationSuggestionDTO aiSuggestion) { this.aiSuggestion = aiSuggestion; }
}
