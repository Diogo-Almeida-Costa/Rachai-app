package com.rachai.attendance.controller;

import com.rachai.api.model.User;
import com.rachai.attendance.dto.classGroupDTOs.ClassGroupRequestDTO;
import com.rachai.attendance.dto.classGroupDTOs.ClassGroupResponseDTO;
import com.rachai.attendance.service.ClassGroupService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pontoai/classgroups")
public class ClassGroupController {

    private static final Logger logger = LoggerFactory.getLogger(ClassGroupController.class);

    @Autowired
    private ClassGroupService classGroupService;

    private User getAuthenticatedUser() {
        return (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

    @PostMapping
    public ResponseEntity<ClassGroupResponseDTO> createClassGroup(@RequestBody ClassGroupRequestDTO dto) {
        User owner = getAuthenticatedUser();
        logger.info("HTTP POST request received to create class group: {} by User ID: {}", dto.getName(), owner.getId());

        ClassGroupResponseDTO created = classGroupService.createClassGroup(dto, owner.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<ClassGroupResponseDTO>> getAllClassGroups() {
        logger.info("HTTP GET request received to fetch all class groups");
        return ResponseEntity.ok(classGroupService.getAllClassGroups());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClassGroupResponseDTO> getClassGroupById(@PathVariable Long id) {
        logger.info("HTTP GET request received for class group ID: {}", id);
        return ResponseEntity.ok(classGroupService.getClassGroupById(id));
    }

    @PostMapping("/{classGroupId}/members/{memberId}")
    public ResponseEntity<ClassGroupResponseDTO> addMember(@PathVariable Long classGroupId, @PathVariable Long memberId) {
        User requester = getAuthenticatedUser();
        logger.info("User ID: {} is attempting to add participant ID: {} to class group ID: {}",
                requester.getId(), memberId, classGroupId);

        return ResponseEntity.ok(classGroupService.addMemberToClassGroup(classGroupId, memberId, requester.getId()));
    }

    @DeleteMapping("/{classGroupId}/members/{memberId}")
    public ResponseEntity<ClassGroupResponseDTO> removeMember(@PathVariable Long classGroupId, @PathVariable Long memberId) {
        User requester = getAuthenticatedUser();
        logger.info("User ID: {} is attempting to remove participant ID: {} from class group ID: {}",
                requester.getId(), memberId, classGroupId);

        return ResponseEntity.ok(classGroupService.removeMemberFromClassGroup(classGroupId, memberId, requester.getId()));
    }
}
