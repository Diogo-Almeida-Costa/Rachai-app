package com.rachai.attendance.controller;

import com.rachai.attendance.dto.AttendanceFrameworkResultDTO;
import com.rachai.attendance.service.AttendanceFrameworkService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;

/**
 * Análogo ao {@code FrameworkExpenseController} do RachAI: expõe a
 * instanciação completa do framework para o domínio de frequência —
 * recebe a lista de presença física (imagem), aciona o OCR, calcula a
 * compensação de carga horária com base na assiduidade real e devolve
 * também a recomendação de atividades extras gerada pela IA.
 */
@RestController
@RequestMapping("/api/framework/attendance")
public class FrameworkAttendanceController {

    @Autowired
    private AttendanceFrameworkService attendanceFrameworkService;

    @PostMapping("/process")
    public ResponseEntity<AttendanceFrameworkResultDTO> processAttendance(
            @RequestParam("file") MultipartFile file,
            @RequestParam("classGroupId") Long classGroupId,
            @RequestParam("sessionDurationHours") BigDecimal sessionDurationHours) {

        AttendanceFrameworkResultDTO result = attendanceFrameworkService
                .processAttendanceWithFramework(file, classGroupId, sessionDurationHours);

        return ResponseEntity.ok(result);
    }
}
