package com.rachai.attendance.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rachai.api.client.GroqApiClient;
import com.rachai.attendance.dto.CompensationSuggestionDTO;
import com.rachai.attendance.instance.ai.PontoAIConfig;
import com.rachai.framework.core.context.ContextManager;
import com.rachai.framework.core.user.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Recurso sugerido pela IA do PontoAI: a partir da carga horária a
 * compensar e da assiduidade real detectada, recomenda atividades extras
 * para cada participante cobrir as horas em falta.
 *
 * Usa o {@code ContextManager} do framework (ponto fixo) para montar o
 * prompt a partir do {@code PontoAIConfig} (extensão flexível) e envia para
 * a IA através do {@code GroqApiClient}, com fallback local caso a IA
 * esteja indisponível — mesmo padrão de resiliência do
 * {@code AiGroupSuggestionService} do RachAI.
 */
@Service
public class CompensationSuggestionService {

    private static final Logger logger = LoggerFactory.getLogger(CompensationSuggestionService.class);

    @Autowired
    private ContextManager contextManager;

    @Autowired
    private PontoAIConfig pontoAIConfig;

    @Autowired
    private GroqApiClient groqApiClient;

    private final ObjectMapper objectMapper = new ObjectMapper();

    public CompensationSuggestionDTO suggestCompensation(Map<User, BigDecimal> hoursToCompensate,
                                                           Map<Long, BigDecimal> attendanceRateByUserId) {
        String contextData = buildContextData(hoursToCompensate, attendanceRateByUserId);
        String prompt = contextManager.buildPrompt(pontoAIConfig, contextData);

        try {
            String aiResponse = groqApiClient.chat(pontoAIConfig.getSystemInstructions(), prompt);
            return parseAiResponse(aiResponse);
        } catch (Exception e) {
            logger.warn("GROQ API failed or returned bad JSON for compensation suggestion. Activating local fallback engine. Reason: {}", e.getMessage());
            return buildFallbackSuggestion(hoursToCompensate);
        }
    }

    private String buildContextData(Map<User, BigDecimal> hoursToCompensate, Map<Long, BigDecimal> attendanceRateByUserId) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== PARTICIPANTES E HORAS A COMPENSAR ===\n");

        for (Map.Entry<User, BigDecimal> entry : hoursToCompensate.entrySet()) {
            User user = entry.getKey();
            BigDecimal rate = attendanceRateByUserId.getOrDefault(user.getId(), BigDecimal.ONE);
            sb.append(String.format("- ID: %d | Nome: %s | Assiduidade real: %.2f%% | Horas a compensar: %.2f\n",
                    user.getId(), user.getName(), rate.doubleValue() * 100, entry.getValue()));
        }

        sb.append("\n=== INSTRUÇÕES ===\n");
        sb.append("Responda APENAS com JSON válido, sem markdown, no formato:\n");
        sb.append("{\n");
        sb.append("  \"activities\": [\"lista de atividades extras sugeridas\"],\n");
        sb.append("  \"totalCompensationHours\": numero total de horas cobertas pelas atividades,\n");
        sb.append("  \"confidence\": numero entre 0 e 1,\n");
        sb.append("  \"reasoning\": \"explicação curta da sugestão\"\n");
        sb.append("}");

        return sb.toString();
    }

    private CompensationSuggestionDTO parseAiResponse(String aiText) throws JsonProcessingException {
        String cleanJson = aiText.trim()
                .replaceAll("(?s)^.*?\\{", "{")
                .replaceAll("(?s)\\}.*?$", "}");

        JsonNode node = objectMapper.readTree(cleanJson);

        List<String> activities = new ArrayList<>();
        JsonNode activitiesNode = node.path("activities");
        if (activitiesNode.isArray()) {
            for (JsonNode activityNode : activitiesNode) {
                activities.add(activityNode.asText());
            }
        }

        return new CompensationSuggestionDTO(
                activities,
                node.path("totalCompensationHours").decimalValue(),
                node.path("confidence").asDouble(0.5),
                node.path("reasoning").asText("")
        );
    }

    private CompensationSuggestionDTO buildFallbackSuggestion(Map<User, BigDecimal> hoursToCompensate) {
        BigDecimal totalHours = hoursToCompensate.values().stream()
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        List<String> activities = List.of(
                "Resumo escrito do conteúdo das aulas perdidas",
                "Exercícios complementares proporcionais às horas em falta",
                "Participação em sessão extra de monitoria/revisão"
        );

        return new CompensationSuggestionDTO(
                activities,
                totalHours,
                0.4,
                "A IA está indisponível no momento; sugestão genérica baseada no total de horas a compensar."
        );
    }
}
