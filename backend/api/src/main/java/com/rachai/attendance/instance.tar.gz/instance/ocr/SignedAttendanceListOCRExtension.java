package com.rachai.attendance.instance.ocr;

import com.rachai.attendance.dto.AttendanceExtractionDTO;
import com.rachai.framework.extension.ocr.IOCRExtension;

import java.time.LocalDate;
import java.util.List;

/**
 * Extensão de OCR do PontoAI: transforma o retorno bruto do processamento
 * de imagem (Tabscanner, orquestrado pelo {@code OCRModule} do framework)
 * em uma lista estruturada de presenças, a partir de uma lista física de
 * chamada assinada pelos participantes.
 *
 * É o equivalente, nesta instanciação, ao {@code ReceiptOCRExtension} do
 * RachAI: o "ponto fixo" (OCRModule) permanece o mesmo, apenas a forma de
 * interpretar o documento muda.
 */
public class SignedAttendanceListOCRExtension implements IOCRExtension<AttendanceExtractionDTO> {

    @Override
    public AttendanceExtractionDTO parseAndValidate(String rawOcrData) {
        // Lógica para converter o retorno do Tabscanner (linhas/itens da
        // lista de chamada) em um AttendanceExtractionDTO. Aqui simulamos
        // a extração de dados, assim como o ReceiptOCRExtension faz para
        // o cupom fiscal do RachAI.
        AttendanceExtractionDTO extraction = new AttendanceExtractionDTO();
        extraction.setSessionDate(LocalDate.now());
        extraction.setTopic("Encontro registrado via lista de presença assinada");
        extraction.setEntries(List.of(
                new AttendanceExtractionDTO.ExtractedEntry("Participante identificado na lista", true)
        ));
        return extraction;
    }

    @Override
    public String getDocumentSchema() {
        return "Lista de Presença: [Turma, Data, Nome do Participante, Assinatura/Marcação de Presença]";
    }
}
