package com.rachai.attendance.model;

import com.rachai.api.model.User;

import javax.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import com.rachai.framework.core.group.IGroupEntity;

/**
 * Representa uma turma/turno de controle de frequência dentro do PontoAI.
 * É o equivalente, nesta instanciação, ao "Group" do RachAI: define o
 * conjunto de participantes (membros) e o recurso total a ser dividido —
 * aqui, a carga horária total da turma.
 */
@Entity
@Table(name = "tb_class_groups")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClassGroup implements IGroupEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false, length = 80)
    private String name;

    @Column(length = 300)
    private String description;

    /**
     * Carga horária total (em horas) que deve ser cumprida/dividida entre
     * os participantes desta turma. É o "recurso a ser dividido" do PontoAI.
     */
    @Column(name = "total_workload_hours", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalWorkloadHours;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "owner_id", nullable = false)
    private User owner;

    @ManyToMany
    @JoinTable(
        name = "class_group_members",
        joinColumns = @JoinColumn(name = "class_group_id"),
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private Set<User> members = new HashSet<>();

    public void addMember(User user) {
        this.members.add(user);
    }

    public void removeMember(User user) {
        this.members.remove(user);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClassGroup that = (ClassGroup) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
