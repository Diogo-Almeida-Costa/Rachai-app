package com.rachai.attendance.instance.resource;

import com.rachai.framework.extension.resource.IResource;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Recurso a ser dividido pelo PontoAI: a carga horária total de uma turma
 * (ClassGroup). É o equivalente, nesta instanciação, ao {@code ExpenseResource}
 * do RachAI — porém aqui "amount" representa horas, não valores monetários.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkloadResource implements IResource {
    private Long id;
    private String name;
    private BigDecimal amount;
}
