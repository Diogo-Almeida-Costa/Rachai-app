package com.rachai.attendance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rachai.attendance.model.ClassSession;

@Repository
public interface ClassSessionRepository extends JpaRepository<ClassSession, Long> {

    List<ClassSession> findByClassGroupIdOrderBySessionDateAsc(Long classGroupId);

    @Query("SELECT COUNT(cs) FROM ClassSession cs WHERE cs.classGroup.id = :classGroupId")
    long countByClassGroupId(@Param("classGroupId") Long classGroupId);
}
