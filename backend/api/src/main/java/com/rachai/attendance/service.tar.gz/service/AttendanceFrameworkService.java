package com.rachai.attendance.service;

import com.rachai.api.exception.BusinessException;
import com.rachai.api.exception.ResourceNotFoundException;
import com.rachai.attendance.dto.AttendanceExtractionDTO;
import com.rachai.attendance.dto.AttendanceFrameworkResultDTO;
import com.rachai.attendance.dto.CompensationSuggestionDTO;
import com.rachai.attendance.instance.ai.PontoAIConfig;
import com.rachai.attendance.instance.ocr.SignedAttendanceListOCRExtension;
import com.rachai.attendance.instance.resource.WorkloadResource;
import com.rachai.attendance.instance.rule.AttendanceCompensationRule;
import com.rachai.attendance.model.AttendanceRecord;
import com.rachai.attendance.model.ClassGroup;
import com.rachai.attendance.model.ClassSession;
import com.rachai.attendance.repository.AttendanceRecordRepository;
import com.rachai.attendance.repository.ClassGroupRepository;
import com.rachai.attendance.repository.ClassSessionRepository;
import com.rachai.framework.core.ocr.OCRModule;
import com.rachai.framework.core.orchestrator.FrameworkOrchestrator;
import com.rachai.framework.core.user.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AttendanceFrameworkService {

    @Autowired
    private OCRModule ocrModule;

    @Autowired
    private FrameworkOrchestrator frameworkOrchestrator;

    @Autowired
    private PontoAIConfig pontoAIConfig;

    @Autowired
    private ClassGroupRepository classGroupRepository;

    @Autowired
    private ClassSessionRepository classSessionRepository;

    @Autowired
    private AttendanceRecordRepository attendanceRecordRepository;

    @Autowired
    private ClassGroupService classGroupService;

    @Autowired
    private CompensationSuggestionService compensationSuggestionService;

    @Transactional
    public AttendanceFrameworkResultDTO processAttendanceWithFramework(MultipartFile file, Long classGroupId,
                                                                        BigDecimal sessionDurationHours) {

        ClassGroup classGroup = classGroupRepository.findById(classGroupId)
                .orElseThrow(() -> new ResourceNotFoundException("Turma não encontrada"));

        if (sessionDurationHours == null || sessionDurationHours.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("A duração da sessão deve ser maior que zero");
        }

        // OCR permanece separado aqui pois precisamos do resultado para persistir a sessão
        AttendanceExtractionDTO extraction = ocrModule.processDocument(file, new SignedAttendanceListOCRExtension());

        ClassSession session = new ClassSession();
        session.setClassGroup(classGroup);
        session.setSessionDate(extraction.getSessionDate());
        session.setDurationHours(sessionDurationHours);
        session.setTopic(extraction.getTopic());
        session = classSessionRepository.save(session);

        persistDetectedAttendance(session, classGroup, extraction);

        List<User> participants = classGroup.getMembers().stream()
                .map(User::fromModel)
                .collect(Collectors.toList());

        Map<Long, BigDecimal> attendanceRateByUserId = new HashMap<>();
        for (User participant : participants) {
            attendanceRateByUserId.put(
                    participant.getId(),
                    classGroupService.calculateRealAttendanceRate(classGroupId, participant.getId())
            );
        }

        WorkloadResource resource = new WorkloadResource(
                classGroup.getId(),
                classGroup.getName(),
                classGroup.getTotalWorkloadHours()
        );

        // Usa o orquestrador do framework para o split (ponto fixo reutilizado)
        Map<User, BigDecimal> hoursToCompensate = frameworkOrchestrator.processWithExistingResource(
                resource,
                pontoAIConfig,
                participants,
                new AttendanceCompensationRule(attendanceRateByUserId)
        );

        CompensationSuggestionDTO aiSuggestion = compensationSuggestionService.suggestCompensation(
                hoursToCompensate, attendanceRateByUserId);

        return new AttendanceFrameworkResultDTO(hoursToCompensate, aiSuggestion);
    }

    private void persistDetectedAttendance(ClassSession session, ClassGroup classGroup, AttendanceExtractionDTO extraction) {
        for (com.rachai.api.model.User member : classGroup.getMembers()) {
            boolean detectedPresent = extraction.getEntries().stream()
                    .anyMatch(entry -> entry.isPresent() && matchesName(entry.getName(), member.getName()));

            AttendanceRecord record = new AttendanceRecord();
            record.setSession(session);
            record.setStudent(member);
            record.setPresent(detectedPresent);
            record.setSourceOcr(true);

            attendanceRecordRepository.save(record);
        }
    }

    private boolean matchesName(String ocrName, String memberName) {
        if (ocrName == null || memberName == null) return false;
        return memberName.toLowerCase().contains(ocrName.toLowerCase())
                || ocrName.toLowerCase().contains(memberName.toLowerCase());
    }
}