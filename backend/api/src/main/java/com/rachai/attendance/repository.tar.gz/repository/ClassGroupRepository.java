package com.rachai.attendance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.rachai.api.model.User;
import com.rachai.attendance.model.ClassGroup;

@Repository
public interface ClassGroupRepository extends JpaRepository<ClassGroup, Long> {
    List<ClassGroup> findByOwner(User owner);
    List<ClassGroup> findByMembersContaining(User member);

    @Query("SELECT cg FROM ClassGroup cg LEFT JOIN FETCH cg.owner LEFT JOIN FETCH cg.members")
    List<ClassGroup> findAllWithDetails();
}
