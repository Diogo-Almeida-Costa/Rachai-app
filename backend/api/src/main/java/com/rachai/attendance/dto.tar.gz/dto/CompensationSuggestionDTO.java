package com.rachai.attendance.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * Resposta estruturada da recomendação de IA: atividades extras sugeridas
 * para compensar a carga horária perdida por faltas, com a respectiva
 * estimativa de horas cobertas e a confiança da sugestão.
 */
public class CompensationSuggestionDTO {

    private List<String> activities;
    private BigDecimal totalCompensationHours;
    private Double confidence;
    private String reasoning;

    public CompensationSuggestionDTO() {}

    public CompensationSuggestionDTO(List<String> activities, BigDecimal totalCompensationHours,
                                      Double confidence, String reasoning) {
        this.activities = activities;
        this.totalCompensationHours = totalCompensationHours;
        this.confidence = confidence;
        this.reasoning = reasoning;
    }

    public List<String> getActivities() { return activities; }
    public void setActivities(List<String> activities) { this.activities = activities; }

    public BigDecimal getTotalCompensationHours() { return totalCompensationHours; }
    public void setTotalCompensationHours(BigDecimal totalCompensationHours) { this.totalCompensationHours = totalCompensationHours; }

    public Double getConfidence() { return confidence; }
    public void setConfidence(Double confidence) { this.confidence = confidence; }

    public String getReasoning() { return reasoning; }
    public void setReasoning(String reasoning) { this.reasoning = reasoning; }
}
