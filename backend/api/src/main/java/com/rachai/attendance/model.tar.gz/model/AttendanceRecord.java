package com.rachai.attendance.model;

import com.rachai.api.model.User;

import javax.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Registro de presença (ou falta) de um participante em uma sessão
 * específica. É a unidade básica de "assiduidade real detectada" usada
 * pela regra de compensação de carga horária do PontoAI.
 */
@Entity
@Table(name = "tb_attendance_records", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"session_id", "student_id"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "session_id", nullable = false)
    private ClassSession session;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private User student;

    @Column(nullable = false)
    private boolean present;

    /**
     * Justificativa opcional da falta, usada como contexto adicional para
     * a recomendação de atividades de compensação feita pela IA.
     */
    @Column(length = 300)
    private String justification;

    /**
     * Indica se este registro foi originado a partir de uma extração
     * automatizada via OCR de uma lista física assinada, em vez de um
     * lançamento manual.
     */
    @Column(name = "source_ocr", nullable = false)
    private boolean sourceOcr;

    @Column(name = "registered_at", updatable = false)
    private LocalDateTime registeredAt;

    @PrePersist
    protected void onCreate() {
        this.registeredAt = LocalDateTime.now();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttendanceRecord that = (AttendanceRecord) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
