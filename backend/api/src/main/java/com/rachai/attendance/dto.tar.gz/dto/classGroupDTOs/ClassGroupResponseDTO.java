package com.rachai.attendance.dto.classGroupDTOs;

import com.rachai.api.dto.userDTOs.UserProfileDTO;

import lombok.*;
import java.math.BigDecimal;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClassGroupResponseDTO {
    private Long id;
    private String name;
    private String description;
    private BigDecimal totalWorkloadHours;
    private UserProfileDTO owner;
    private Set<UserProfileDTO> members;
}
