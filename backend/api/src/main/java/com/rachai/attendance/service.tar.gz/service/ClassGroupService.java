package com.rachai.attendance.service;

import com.rachai.api.exception.ResourceNotFoundException;
import com.rachai.api.mapper.DozerMapper;
import com.rachai.api.model.User;
import com.rachai.attendance.dto.classGroupDTOs.ClassGroupRequestDTO;
import com.rachai.attendance.dto.classGroupDTOs.ClassGroupResponseDTO;
import com.rachai.attendance.model.ClassGroup;
import com.rachai.attendance.model.ClassSession;
import com.rachai.attendance.repository.AttendanceRecordRepository;
import com.rachai.attendance.repository.ClassGroupRepository;
import com.rachai.attendance.repository.ClassSessionRepository;
import com.rachai.framework.core.group.BaseGroupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

@Service
public class ClassGroupService extends BaseGroupService<ClassGroup, ClassGroupRequestDTO, ClassGroupResponseDTO> {

    private static final Logger logger = LoggerFactory.getLogger(ClassGroupService.class);

    @Autowired
    private ClassGroupRepository classGroupRepository;

    @Autowired
    private ClassSessionRepository classSessionRepository;

    @Autowired
    private AttendanceRecordRepository attendanceRecordRepository;

    // --- Implementações obrigatórias do BaseGroupService ---

    @Override
    protected JpaRepository<ClassGroup, Long> getRepository() { return classGroupRepository; }

    @Override
    protected ClassGroup createEntityFromDto(ClassGroupRequestDTO dto) {
        return DozerMapper.parseObject(dto, ClassGroup.class);
    }

    @Override
    protected ClassGroupResponseDTO toResponseDto(ClassGroup entity) {
        return DozerMapper.parseObject(entity, ClassGroupResponseDTO.class);
    }

    @Override
    protected String getEntityName() { return "Turma"; }

    @Override
    protected void setOwner(ClassGroup entity, User owner) { entity.setOwner(owner); }

    // --- Operações específicas do domínio de frequência ---

    @Transactional(readOnly = true)
    public List<ClassGroupResponseDTO> getAllClassGroups() {
        return classGroupRepository.findAllWithDetails().stream()
                .map(this::toResponseDto).toList();
    }

    @Transactional
    public ClassGroupResponseDTO createClassGroup(ClassGroupRequestDTO dto, Long ownerId) {
        return create(dto, ownerId);
    }

    @Transactional(readOnly = true)
    public ClassGroupResponseDTO getClassGroupById(Long id) {
        return getById(id);
    }

    @Transactional
    public ClassGroupResponseDTO addMemberToClassGroup(Long classGroupId, Long memberId, Long requesterId) {
        return addMember(classGroupId, memberId, requesterId);
    }

    @Transactional
    public ClassGroupResponseDTO removeMemberFromClassGroup(Long classGroupId, Long memberId, Long requesterId) {
        return removeMember(classGroupId, memberId, requesterId);
    }

    @Transactional
    public ClassSession registerSession(Long classGroupId, LocalDate sessionDate,
                                         BigDecimal durationHours, String topic) {
        ClassGroup classGroup = findOrThrow(classGroupId);

        if (durationHours == null || durationHours.compareTo(BigDecimal.ZERO) <= 0) {
            throw new com.rachai.api.exception.BusinessException("A duração da sessão deve ser maior que zero");
        }

        ClassSession session = new ClassSession();
        session.setClassGroup(classGroup);
        session.setSessionDate(sessionDate != null ? sessionDate : LocalDate.now());
        session.setDurationHours(durationHours);
        session.setTopic(topic);

        return classSessionRepository.save(session);
    }

    @Transactional(readOnly = true)
    public BigDecimal calculateRealAttendanceRate(Long classGroupId, Long studentId) {
        long total = attendanceRecordRepository.countTotalRecords(classGroupId, studentId);
        if (total == 0) return BigDecimal.ONE;

        long present = attendanceRecordRepository.countPresences(classGroupId, studentId);
        return BigDecimal.valueOf(present)
                .divide(BigDecimal.valueOf(total), 4, RoundingMode.HALF_UP);
    }
}